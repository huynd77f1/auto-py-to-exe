# Spykeyboard


This is a script which allows us to generate an undetectable keylogger which sends the captured keys to our gmail mail. Once we generated our keylogger in our kali linux we would have to pass the .py file to a windows machine to convert it to an .exe. The tool is in development.

Es:

Este es un script el cual nos permite generar un keylogger indetectable el cual nos envía las teclas capturadas a nuestro correo de gmail. Una vez generamos nuestro keylogger en nuestra kali linux tendriamos que pasar el archivo .py a una maquina windows para convertirlo en un .exe. La herramienta un esta en desarrollo.

install module in linux and windows:

pip install keyboard



![Screenshot](https://github.com/Sh4rk0-666/Spykeyboard/blob/master/Screen%20Shot%202018-08-31%20at%209.37.31%20PM.png)

# Compile to .exe

![Screenshot](https://github.com/Sh4rk0-666/Spykeyboard/blob/master/Screenshot%20(39).png)
